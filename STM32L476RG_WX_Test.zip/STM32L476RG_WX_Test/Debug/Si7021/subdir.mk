################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../Si7021/Si7021.cpp 

OBJS += \
./Si7021/Si7021.o 

CPP_DEPS += \
./Si7021/Si7021.d 


# Each subdirectory must supply rules for building sources it contributes
Si7021/%.o Si7021/%.su Si7021/%.cyclo: ../Si7021/%.cpp Si7021/subdir.mk
	arm-none-eabi-g++ "$<" -mcpu=cortex-m4 -std=gnu++14 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32L476xx -c -I../Core/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32L4xx/Include -I../Drivers/CMSIS/Include -I"D:/stm32cubeide/STM32_Nucleo/STM32_L432KC/STM32L476RG_WX_Test/Si7021" -I"D:/stm32cubeide/STM32_Nucleo/STM32_L432KC/STM32L476RG_WX_Test/wxutil" -I"D:/stm32cubeide/STM32_Nucleo/STM32_L432KC/STM32L476RG_WX_Test/mpl3115a2" -I"D:/stm32cubeide/STM32_Nucleo/STM32_L432KC/STM32L476RG_WX_Test/rtc-lib/include" -O0 -ffunction-sections -fdata-sections -fno-exceptions -fno-rtti -fno-use-cxa-atexit -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Si7021

clean-Si7021:
	-$(RM) ./Si7021/Si7021.cyclo ./Si7021/Si7021.d ./Si7021/Si7021.o ./Si7021/Si7021.su

.PHONY: clean-Si7021

