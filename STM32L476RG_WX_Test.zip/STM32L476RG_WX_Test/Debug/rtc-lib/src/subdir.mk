################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../rtc-lib/src/RTC_DS1307.cpp \
../rtc-lib/src/RTC_DS3231.cpp \
../rtc-lib/src/RTC_PCF8523.cpp \
../rtc-lib/src/RTC_PCF8563.cpp \
../rtc-lib/src/RTClib.cpp 

C_SRCS += \
../rtc-lib/src/STM32L4xx_RTC_Lib.c 

C_DEPS += \
./rtc-lib/src/STM32L4xx_RTC_Lib.d 

OBJS += \
./rtc-lib/src/RTC_DS1307.o \
./rtc-lib/src/RTC_DS3231.o \
./rtc-lib/src/RTC_PCF8523.o \
./rtc-lib/src/RTC_PCF8563.o \
./rtc-lib/src/RTClib.o \
./rtc-lib/src/STM32L4xx_RTC_Lib.o 

CPP_DEPS += \
./rtc-lib/src/RTC_DS1307.d \
./rtc-lib/src/RTC_DS3231.d \
./rtc-lib/src/RTC_PCF8523.d \
./rtc-lib/src/RTC_PCF8563.d \
./rtc-lib/src/RTClib.d 


# Each subdirectory must supply rules for building sources it contributes
rtc-lib/src/%.o rtc-lib/src/%.su rtc-lib/src/%.cyclo: ../rtc-lib/src/%.cpp rtc-lib/src/subdir.mk
	arm-none-eabi-g++ "$<" -mcpu=cortex-m4 -std=gnu++14 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32L476xx -c -I../Core/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32L4xx/Include -I../Drivers/CMSIS/Include -I"D:/stm32cubeide/STM32_Nucleo/STM32_L432KC/STM32L476RG_WX_Test/Si7021" -I"D:/stm32cubeide/STM32_Nucleo/STM32_L432KC/STM32L476RG_WX_Test/wxutil" -I"D:/stm32cubeide/STM32_Nucleo/STM32_L432KC/STM32L476RG_WX_Test/mpl3115a2" -I"D:/stm32cubeide/STM32_Nucleo/STM32_L432KC/STM32L476RG_WX_Test/rtc-lib/include" -O0 -ffunction-sections -fdata-sections -fno-exceptions -fno-rtti -fno-use-cxa-atexit -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
rtc-lib/src/%.o rtc-lib/src/%.su rtc-lib/src/%.cyclo: ../rtc-lib/src/%.c rtc-lib/src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32L476xx -c -I../Core/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32L4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-rtc-2d-lib-2f-src

clean-rtc-2d-lib-2f-src:
	-$(RM) ./rtc-lib/src/RTC_DS1307.cyclo ./rtc-lib/src/RTC_DS1307.d ./rtc-lib/src/RTC_DS1307.o ./rtc-lib/src/RTC_DS1307.su ./rtc-lib/src/RTC_DS3231.cyclo ./rtc-lib/src/RTC_DS3231.d ./rtc-lib/src/RTC_DS3231.o ./rtc-lib/src/RTC_DS3231.su ./rtc-lib/src/RTC_PCF8523.cyclo ./rtc-lib/src/RTC_PCF8523.d ./rtc-lib/src/RTC_PCF8523.o ./rtc-lib/src/RTC_PCF8523.su ./rtc-lib/src/RTC_PCF8563.cyclo ./rtc-lib/src/RTC_PCF8563.d ./rtc-lib/src/RTC_PCF8563.o ./rtc-lib/src/RTC_PCF8563.su ./rtc-lib/src/RTClib.cyclo ./rtc-lib/src/RTClib.d ./rtc-lib/src/RTClib.o ./rtc-lib/src/RTClib.su ./rtc-lib/src/STM32L4xx_RTC_Lib.cyclo ./rtc-lib/src/STM32L4xx_RTC_Lib.d ./rtc-lib/src/STM32L4xx_RTC_Lib.o ./rtc-lib/src/STM32L4xx_RTC_Lib.su

.PHONY: clean-rtc-2d-lib-2f-src

